"""Frozen notebook-runtime installer: no package install into Colab base Python."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Literal

UV_VERSION = '0.13.0'
UV_WHEEL_SHA256 = '52c7da0fd9056d9551124777ec77de53f0df7017daf8f98a19e947b7837416ed'
PYTHON_VERSION = '3.11.17'
PYTHON_SHA256 = '08ad3f0a96b536082d6020a29830712c55346dca555f81a337c628f00369f57a'
Profile = Literal['cpu', 'transformers', 'serving']


def install_runtime(directory: Path, profile: Profile = 'cpu') -> Path:
    """Sync a reviewed frozen graph, without system/user-site inheritance.

    Parameters
    ----------
    directory : Path
        Fresh hash-verified candidate directory containing pyproject/uv.lock.
    profile : {'cpu', 'transformers', 'serving'}, default 'cpu'
        CPU teaching only, optional CUDA quantization, or optional API serving.
        Extras are monotonic: serving never removes a previous NF4 dependency.

    Returns
    -------
    Path
        Verified .venv/bin/python, managed CPython 3.11.17 on Linux x86_64.

    Raises
    ------
    RuntimeError
        Unknown profile, modified inputs, unsupported platform, wrong
        interpreter/hash or previously imported GPU packages during sync.
    subprocess.CalledProcessError
        A bounded installer operation fails; partial logs remain in directory.

    Notes
    -----
    This is trusted environment isolation, not an OS sandbox. Provider kernel,
    NVIDIA driver and OS remain provider-owned. No ready status follows from
    successful installation. Each revised notebook must first pass a browser rehearsal.
    """
    if profile not in ('cpu','transformers','serving'):
        raise RuntimeError('Unknown reviewed runtime profile')
    if sys.platform != 'linux' or os.uname().machine != 'x86_64':
        raise RuntimeError('Candidate targets Linux x86_64, not local GPU execution')
    directory = directory.resolve()
    manifest = json.loads((directory/'manifest.json').read_text())
    for name, digest in manifest['files'].items():
        path = directory/name
        if (not path.resolve().is_relative_to(directory) or path.is_symlink()
                or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
            raise RuntimeError('Changed candidate input: '+name)
    state_path = directory/'installed-profiles.json'
    selected = set(json.loads(state_path.read_text())) if state_path.exists() else set()
    if profile != 'cpu':
        selected.add(profile)
    if selected - {'transformers','serving'}:
        raise RuntimeError('Unknown saved profile')
    if any(name in sys.modules for name in ('torch','vllm','bitsandbytes')):
        raise RuntimeError('GPU modules already loaded; preserve evidence before a fresh worker')
    installer = directory/'installer/bin/uv'
    if not installer.exists():
        requirement = directory/'installer-requirements.txt'
        with requirement.open('x') as destination:
            destination.write(f'uv=={UV_VERSION} --hash=sha256:{UV_WHEEL_SHA256}\n')
        with (directory/'installer.log').open('x') as log:
            subprocess.run([sys.executable,'-I','-m','pip','install','--no-deps',
                '--only-binary=:all:','--require-hashes','--target',str(directory/'installer'),
                '-r',str(requirement)],check=True,stdin=subprocess.DEVNULL,
                stdout=log,stderr=subprocess.STDOUT,timeout=300)
    actual = subprocess.check_output([str(installer),'--version'],text=True).strip()
    if actual != 'uv 0.13.0 (x86_64-unknown-linux-gnu)':
        raise RuntimeError('Unexpected installer identity: '+actual)
    environment = {key: value for key,value in os.environ.items()
                   if not key.startswith(('PYTHON','PIP_','UV_'))
                   and key not in ('VIRTUAL_ENV','CONDA_PREFIX')}
    environment.update(UV_CACHE_DIR=str(directory/'uv-cache'),
        UV_PYTHON_INSTALL_DIR=str(directory/'interpreters'), UV_MANAGED_PYTHON='true',
        UV_NO_CONFIG='true', UV_HTTP_TIMEOUT='300', UV_HTTP_RETRIES='3')
    command = [str(installer),'sync','--frozen','--no-dev','--managed-python',
               '--python',PYTHON_VERSION]
    for extra in sorted(selected):
        command.extend(['--extra',extra])
    with (directory/f'sync-{profile}.log').open('a') as log:
        subprocess.run(command,cwd=directory,env=environment,check=True,
                       stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,timeout=3000)
    python = directory/'.venv/bin/python'
    probe = (
        "import hashlib,json,site,ssl,sys;from pathlib import Path;"
        "print(json.dumps(dict(version=sys.version.split()[0],prefix=sys.prefix,"
        "base=sys.base_prefix,user_site=site.ENABLE_USER_SITE,path=sys.path,"
        "sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),"
        "openssl=ssl.OPENSSL_VERSION)))")
    identity = json.loads(subprocess.check_output([str(python),'-I','-c',probe],text=True))
    configuration = (directory/'.venv/pyvenv.cfg').read_text().lower()
    if (identity['version'] != PYTHON_VERSION or identity['sha256'] != PYTHON_SHA256
            or identity['prefix'] == identity['base'] or identity['user_site'] is not False
            or Path(identity['prefix']).resolve() != (directory/'.venv').resolve()
            or 'include-system-site-packages = false' not in configuration
            or any('/usr/local/lib/python' in p for p in identity['path'])):
        raise RuntimeError('Unisolated or wrong managed interpreter: '+json.dumps(identity))
    state_path.write_text(json.dumps(sorted(selected))+'\n')
    (directory/f'identity-{profile}.json').write_text(json.dumps(identity,indent=2)+'\n')
    return python
