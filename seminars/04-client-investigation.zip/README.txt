Topic 04: ML service investigation v3
Open the notebook; A-C are self-contained CPU work. GPU execution defaults false.
The teaching/*.py files and provided-runtime.py are readable provided infrastructure,
not solutions to budget/scoring functions. Task data is embedded in the notebook;
the 12-ticket Transformers FP16 reference is not a vLLM task measurement.
recorded-capture.json is historical
RTX 5070 Ti evidence, not your service result. D requires a fresh compatible idle
CUDA runtime and the course 24 GiB available-RAM gate. Never expose the loopback
server through a public tunnel. D compares two calibration settings; choose and
freeze before E loads held-out, restarting the cached model.
Standard-RAM Colab and learner completion are not certified.
Keep your CPU decision separate from the fresh validated v3 service JSON.
Current v3 instructor references passed on T4 / High RAM: separate prompt and format challengers on calibration; each selected baseline before held-out and verified both teardowns. Format itself was not evaluated on held-out.
