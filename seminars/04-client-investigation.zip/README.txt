Topic 04: ML service investigation v3
Open the notebook; A-C are self-contained CPU work. GPU execution defaults false.
The teaching/*.py files and provided-runtime.py are readable provided infrastructure,
not solutions to budget/scoring functions. Task data is embedded in the notebook;
the 12-ticket Transformers FP16 reference is not a vLLM task measurement.
recorded-capture.json is historical
RTX 5070 Ti evidence, not your service result. D requires a fresh compatible idle
CUDA runtime and the provisional student small-model profile. Startup checks
5 GiB host/device headroom; running checks 2 GiB host and 512 MiB device headroom.
These stop rules are not validated free-Colab requirements. Never expose the loopback
server through a public tunnel. D compares two calibration settings; choose and
freeze before E loads held-out, restarting the cached model.
Use the provided managed Python 3.11.17 CPU/serving profiles. Scientific code
executes through %%lsm in a separate worker, not inherited Colab packages.
The runtime ZIP is source-only, not results. OS/driver remain provider-owned.
Free GPU quota and independent learner completion are not certified.
Keep your CPU decision separate from the fresh validated v3 service JSON.
provided-runtime.py is the exact solution-free literal runner in notebook topic04-38,
not the historical operator helper. Distribution vLLM0.30.0+cu129 and module0.30.0
are distinct identities; do not install the old 0.29 documentation environment.
Current isolated v3 code passed two exact live-browser rehearsals per prompt/format route on 12 October 2026 (UTC), T4 / standard RAM (12.67 GB), without High RAM. Each route froze a calibration choice before held-out and verified owned-server teardown. Solutions and new run results remain private. Readiness-only prose changed after the exact-code rehearsals; see data/notebook-release.json on Pages for original and delivered hashes.
