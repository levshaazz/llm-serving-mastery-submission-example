"""Execute visible cells in one managed, isolated Python.

This is a local trusted-code transport, NOT an untrusted-code sandbox. Notebook
execution remains in the live Colab browser. No credential or Drive access.
"""
import json
import os
from pathlib import Path
import sys
from typing import Any, TypedDict

from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output


class CellReply(TypedDict):
    """Captured cell result; MIME data is rendered by the provider frontend."""

    ok: bool
    stdout: str
    stderr: str
    displays: list[dict[str, Any]]
    error: str | None
    python: str


class NotebookWorkerShell(InteractiveShell):
    """Headless inline shell; no GUI/event-loop integration is requested."""

    def enable_gui(self, gui: str | None = None) -> None:
        """Accept only the no-GUI mode selected by the inline backend.

        Parameters
        ----------
        gui : str or None, default None
            Inline plotting resolves to None. Real GUI loops are unsupported.

        Returns
        -------
        None
            Leaves GUI integration disabled; rich displays use MIME capture.

        Raises
        ------
        RuntimeError
            A non-inline GUI event loop is requested.
        """
        if gui is not None:
            raise RuntimeError('Only headless inline display is supported')


def execute_cell(shell: InteractiveShell, source: str) -> CellReply:
    """Run one visible source cell without replacing its contents or counts.

    Parameters
    ----------
    shell : InteractiveShell
        Persistent worker namespace, not the provider notebook namespace.
    source : str
        Actual trusted cell source; supports Python and top-level await.

    Returns
    -------
    CellReply
        Literal stdout/stderr, captured MIME displays and actual failure name.
        Native execution counters remain owned by Colab, never synthesized.

    Notes
    -----
    Student failures are returned, not hidden or automatically retried. This
    transport does not certify notebook or learner readiness.
    """
    with capture_output(stdout=True, stderr=True, display=True) as captured:
        result = shell.run_cell(source, store_history=False)
    failure = result.error_before_exec or result.error_in_exec
    return dict(ok=failure is None, stdout=captured.stdout, stderr=captured.stderr,
                displays=[dict(data=o.data, metadata=o.metadata) for o in captured.outputs],
                error=None if failure is None else type(failure).__name__ + ': ' + str(failure),
                python=sys.version.split()[0])


def main() -> None:
    """Serve bounded, newline-delimited cell requests on owned local pipes.

    Returns
    -------
    None
        Exits on EOF or shutdown; never accepts TCP or arbitrary remote clients.
    """
    if sys.version.split()[0] != '3.11.17' or sys.prefix == sys.base_prefix:
        raise RuntimeError('Expected managed CPython 3.11.17 inside a virtual environment')
    configuration = Path(sys.prefix) / 'pyvenv.cfg'
    if 'include-system-site-packages = false' not in configuration.read_text().lower():
        raise RuntimeError('System site packages must be disabled')
    if os.environ.get('PYTHONPATH') or os.environ.get('PYTHONHOME'):
        raise RuntimeError('Python search-path inheritance is forbidden')
    reply_fd = int(os.environ.pop('LSM_ISOLATED_REPLY_FD'))
    if reply_fd <= 2:
        raise RuntimeError('Reply channel must be separate from process console')
    os.set_inheritable(reply_fd, False)
    reply_channel = os.fdopen(reply_fd, 'w')
    shell = NotebookWorkerShell.instance()
    shell.enable_matplotlib('inline')
    for line in sys.stdin:
        if len(line) > 16 * 1024 * 1024:
            raise RuntimeError('Cell source exceeds the explicit transport budget')
        request = json.loads(line)
        if request == {'shutdown': True}:
            break
        if set(request) != {'source'} or not isinstance(request['source'], str):
            raise ValueError('Expected one literal source cell')
        reply = execute_cell(shell, request['source'])
        encoded = json.dumps(reply, ensure_ascii=True, allow_nan=False)
        if len(encoded) > 64 * 1024 * 1024:
            raise RuntimeError('Cell output exceeds the explicit transport budget')
        print(encoded, file=reply_channel, flush=True)


if __name__ == '__main__':
    main()
