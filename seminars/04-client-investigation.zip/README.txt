Topic 04: ML service investigation v3
Open the notebook; A-C are self-contained CPU work. GPU execution defaults false.
The teaching/*.py files and provided-runtime.py are readable provided infrastructure,
not solutions to budget/scoring functions. Task data is embedded in the notebook;
the 12-ticket Transformers FP16 reference is not a vLLM task measurement.
recorded-capture.json is historical
RTX 5070 Ti evidence, not your service result. D requires a fresh compatible idle
CUDA runtime and the provisional student small-model profile. Startup checks
5 GiB host/device headroom; running checks 2 GiB host and 512 MiB device headroom.
These stop rules are not validated free-Colab requirements. Never expose the loopback
server through a public tunnel. D compares two calibration settings; choose and
freeze before E loads held-out, restarting the cached model.
Free GPU quota and independent learner completion are not certified.
Keep your CPU decision separate from the fresh validated v3 service JSON.
Current v3 code passed live-browser rehearsals on 11 October 2026 on T4 / standard RAM (12.67 GB), without High RAM. Prompt and format routes each froze a calibration choice before held-out and verified owned-server teardown. Solutions and new run results remain private. Readiness-only prose changed after the exact-code rehearsals; see data/notebook-release.json on Pages for original and delivered hashes.
