TOPIC05 STUDENT INVESTIGATION - technical execution and learner validation differ.

Exact current code passed two full instructor browser rehearsals on 13 October
2026 (UTC), Tesla T4 / standard 12.67 GB RAM, High RAM off, paid account.
Instructor solutions and new results remain private. See the current topic page:
https://levshaazz.github.io/llm-serving-mastery/en/topics/05/#readiness

Open the unsolved notebook and keep this exact helper/runtime bundle. Scientific
cells use %%lsm inside managed CPython3.11.17; do not install into Colab's kernel.
One visible cell performs one learning action and one interpretable output.
The readable helpers are supplied infrastructure, not hidden student solutions.

1. Explain Qwen24layers /2KVheads /64features and12KiB per FP16 retained position.
2. Implement account_kv: round independently per request. Change block size8/16/32.
   Plot unchanged live payload versus tail capacity. Fourteen fixtures must pass.
3. Explain global page masses; implement arrived FIFO selection. Ten fixtures must
   pass. Inspect both entire traces; toy ticks are not GPU seconds/utilization.
4. Inspect all twelve literal tickets and gold labels. Write rate/quality/falsifier
   before installing, including a frozen classroom correct/invalid acceptance rule.
5. Keep cohort1, add4; repeats3/cap16/pinned Qwen/FP16/greedy/EOS/penalty1.0 fixed.
   RUN_GPU remainsFalse until your functions/explanations and resources pass.
   T4 standard-RAM execution was observed; free GPU availability is not guaranteed.
6. After an ACTUAL complete run, inspect twelve engine/size/repeat summaries,
   actual three repeat rate points,3x4 quality matrices and literal disagreements.
   Write choice/evidence/alternative/limitation; refusal is a legitimate decision.
   Download the exact attempt ZIP and modified notebook. Preserve partial failures.

This OFFLINE experiment submits≤4 requests per separate library call. It does
not observe a fifth queued request entering a freed slot: refill is the toy exercise.
It changes entire stacks, not an isolated PagedAttention switch; no TTFT, individual
E2E, reliable p95, free GPU quota, learner validation or deployment quality claimed.
72 predictions/45cohort clocks per engine:144predictions/90clocks over both, NOT
144 independent tickets. Rates divide12 attempts by sum(cohort wall seconds).
Bad/invalid/empty task outputs are retained, not repaired or dropped.

The workload-specific6GiB initial host/device resource bounds passed the observed
rehearsal; samples are not peak-memory monitoring, a judge relaxation or an OS sandbox.
Owned pipeline allocation/TERM cleanup was observed; this does not certify the
full Colab Stop or active vLLM cancellation path. Exact displayed result archives
were retained, but automatic browser file saving is unverified. Save and inspect
your own files before disconnecting. Predictions are written before inference;
the notebook does not automatically lock the variable. Do not rewrite them later.
No private instructor handbook, reference solutions, credentials, raw run captures,
checkpoint or runtime cache is included. SHA256SUMS.json is a drift manifest, not
a signature. The notebook embeds its own helper hashes; editing only a companion
file does not silently edit the embedded notebook source.
