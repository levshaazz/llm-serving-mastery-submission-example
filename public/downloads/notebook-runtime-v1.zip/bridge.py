"""Live-browser transport for literal cells in a managed Python worker."""
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time
from typing import Any


class IsolatedCellBridge:
    """One owned worker. Parent imports no model or scientific libraries."""

    def __init__(self, python: Path, worker: Path, *, timeout_s: float = 1200) -> None:
        """Start a managed Python process with isolated import discovery.

        Parameters
        ----------
        python : Path
            Exact managed virtual-environment executable.
        worker : Path
            Hash-verified transport source, not student solutions.
        timeout_s : float, default 1200
            Maximum wall seconds per cell, not a model measurement clock.

        Returns
        -------
        None
            Owns only the newly created worker process group.
        """
        if timeout_s <= 0:
            raise ValueError('A positive cell deadline is required')
        environment = {key: value for key, value in os.environ.items()
                       if not key.startswith(('PYTHON', 'PIP_', 'UV_'))
                       and key not in ('VIRTUAL_ENV', 'CONDA_PREFIX')}
        environment.update(PYTHONNOUSERSITE='1', MPLBACKEND='module://matplotlib_inline.backend_inline',
                           HF_HUB_DISABLE_TELEMETRY='1', VLLM_NO_USAGE_STATS='1')
        # Runtime inputs stay immutable across later profile installations.
        # Teaching-data downloads and generated artifacts use a separate cwd.
        workspace = worker.parent / 'workspace'
        workspace.mkdir(exist_ok=False)
        self.log = worker.with_name('worker-transport.log').open('x')
        # Descendants may legitimately write directly to fd1. Give replies an
        # independent, non-inherited channel; stdout/stderr stay in the log.
        reply_read, reply_write = os.pipe()
        environment['LSM_ISOLATED_REPLY_FD'] = str(reply_write)
        self.output = os.fdopen(reply_read, 'rb')
        self.console_offset = 0
        self.process = subprocess.Popen([str(python), '-I', str(worker)],
            stdin=subprocess.PIPE, stdout=self.log, stderr=self.log,
            pass_fds=(reply_write,), cwd=workspace, env=environment, start_new_session=True)
        os.close(reply_write)
        self.timeout_s = timeout_s
        # A live child PID alone does not prove that its shell initialized.
        self.timeout_s = min(timeout_s, 30)
        try:
            ready = self.execute('pass')
            if not ready['ok'] or ready['python'] != '3.11.17':
                raise RuntimeError('Managed worker startup identity failed')
        except BaseException:
            self.close()
            raise
        finally:
            self.timeout_s = timeout_s

    def execute(self, source: str) -> dict[str, Any]:
        """Transmit a literal cell and retain its actual reply without retry.

        Parameters
        ----------
        source : str
            Visible trusted notebook source, excluding the magic declaration.

        Returns
        -------
        dict[str, Any]
            Actual worker reply with stdout/stderr/displays/ok/error/python.

        Raises
        ------
        RuntimeError
            Worker exited, malformed reply or output budget exceeded.
        TimeoutError
            Cell deadline exceeded. Worker is stopped, not silently retried.
        """
        if self.process.poll() is not None:
            raise RuntimeError('Owned worker stopped; preserve its log, do not recreate silently')
        payload = json.dumps({'source': source}).encode() + b'\n'
        if len(payload) > 16 * 1024 * 1024:
            raise ValueError('Cell source exceeds the explicit transport budget')
        self.process.stdin.write(payload)
        self.process.stdin.flush()
        deadline = time.monotonic() + self.timeout_s
        received = bytearray()
        with selectors.DefaultSelector() as reader:
            reader.register(self.output, selectors.EVENT_READ)
            while time.monotonic() < deadline:
                if not reader.select(min(.5, max(0, deadline-time.monotonic()))):
                    continue
                chunk = os.read(self.output.fileno(), 65536)
                if not chunk:
                    raise RuntimeError('Worker ended before a complete reply; inspect worker-transport.log')
                received.extend(chunk)
                if len(received) > 64 * 1024 * 1024:
                    self.close()
                    raise RuntimeError('Cell output exceeds the explicit transport budget')
                if received.endswith(b'\n'):
                    reply = json.loads(received)
                    if set(reply) != {'ok','stdout','stderr','displays','error','python'}:
                        raise RuntimeError('Malformed isolated transport reply')
                    # Keep literal child console visible, but separate it from
                    # Python/MIME output and never reinterpret it as a reply.
                    with open(self.log.name, 'rb') as console:
                        console.seek(self.console_offset)
                        child_output = console.read(64 * 1024 * 1024 + 1)
                        self.console_offset = console.tell()
                    if len(child_output) > 64 * 1024 * 1024:
                        self.close()
                        raise RuntimeError('Child console exceeds explicit output budget; full log retained')
                    if child_output:
                        reply['stderr'] += ('\n[Owned child console: combined stdout/stderr]\n'
                                            + child_output.decode('utf-8', errors='replace'))
                    return reply
        self.close()
        raise TimeoutError('Cell deadline exceeded; preserve the failed attempt')

    def render(self, source: str) -> None:
        """Render one actual reply in Colab; propagate failures unchanged.

        Parameters
        ----------
        source : str
            Visible code forwarded to the owned worker.

        Returns
        -------
        None
            Renders captured learning output; never starts inference on review.
        """
        from IPython.display import display
        try:
            reply = self.execute(source)
        except KeyboardInterrupt:
            # Colab interrupts the provider kernel, not necessarily its child.
            # Never leave that owned computation silently running in the VM.
            self.close()
            raise
        for key in ('stdout','stderr'):
            if reply[key]:
                print(reply[key], end='')
        for output in reply['displays']:
            display(output['data'], raw=True, metadata=output['metadata'])
        if not reply['ok']:
            raise RuntimeError(reply['error'])

    def close(self) -> None:
        """Close only this owned worker, with bounded termination fallback.

        Returns
        -------
        None
            Stops the worker; does not delete its VM, notebook or evidence.
        """
        if self.process.poll() is None:
            try:
                self.process.stdin.write(b'{"shutdown":true}\n')
                self.process.stdin.flush()
                self.process.wait(timeout=10)
            except (BrokenPipeError, subprocess.TimeoutExpired):
                try:
                    os.killpg(self.process.pid, signal.SIGTERM)
                    self.process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(self.process.pid, signal.SIGKILL)
                    self.process.wait(timeout=5)
        self.log.close()
        self.output.close()
